import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from 'src/app/shared/api-service.service';
import { NgForm } from '@angular/forms';
import { Score } from 'src/app/shared/score.model'

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styles: [
  ]
})
export class InputComponent implements OnInit {

  constructor(public service: ApiServiceService) { }

  isSubmit: boolean = false;
  lstNumbers: Score = new Score();

  ngOnInit(): void {
  }

  onSubmit(form: NgForm) {
    this.service.postCrunch().subscribe(result => {
      this.lstNumbers = result as Score;
      this.isSubmit = true;
    },
      error => { console.log(error); });
  }

}
