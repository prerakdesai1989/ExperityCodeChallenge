export class Crunch {
  sampleMaxCnt = 0;
  patientScore = 0;
  docScore = 0;
  uploadMsg = '';
}
