import { Injectable } from '@angular/core';
import { Crunch } from 'src/app/shared/crunch.model';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {

  constructor(private http: HttpClient) { }

  readonly baseUrl = 'https://localhost:44332/api/Crunch'
  formData: Crunch = new Crunch();

  postCrunch() {
    return this.http.post(this.baseUrl, this.formData);
  }
}
