export class Score {
  scoreData: ScoreData[];
  myMsg = '';
}

export class ScoreData {
  sampleNo = 0;
  score = '';
}
